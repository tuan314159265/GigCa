# Learning figures

PNG (200 dpi) and SVG for reports; CSV/JSON contain source values.

- Wait curve: five independent fits, fixed seeded nested random subsets of training spells; not epochs. One seed only, no confidence bands; small differences are not significance tests.
- Boosting curves: raw quantile pinball loss at each fitted stage; conformal correction is not applied. No early stopping or model selection from these plots.
- Test calibration: five equal-count prediction groups, censoring-aware Kaplan–Meier estimates; no confidence bands and dependent synthetic observations.
- Test intervals: all test cycles, sorted by median prediction; not a time series.
- Test is used for final reporting only; never choose parameters by inspecting test plots.
- All figures describe synthetic data, not performance on real drivers.
